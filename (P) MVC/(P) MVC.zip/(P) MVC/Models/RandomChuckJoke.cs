﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _P__MVC.Models
{
    public class RandomChuckJoke
    {
        public string icon_url { get; set; }
        public string id { get; set; }
        public string url { get; set; }
        public string value { get; set; }
    }
}